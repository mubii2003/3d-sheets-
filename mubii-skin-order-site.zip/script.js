
async function fetchImages() {
  const folderId = window.folderId;
  const apiUrl = `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents&key=AIzaSyD-EXAMPLEKEY&fields=files(id,name,mimeType)`;
  const response = await fetch(apiUrl);
  const data = await response.json();
  const gallery = document.getElementById("gallery");

  data.files.forEach(file => {
    if (file.mimeType.includes("image")) {
      const imgURL = `https://drive.google.com/uc?export=view&id=${file.id}`;
      const code = file.name.split(".")[0];
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <img src="${imgURL}" alt="${code}">
        <h3>${code}</h3>
        <label>مقدار:</label>
        <input type="number" id="qty-${code}" min="0" value="0">
      `;
      gallery.appendChild(card);
    }
  });
}

function sendOrder() {
  const inputs = document.querySelectorAll("input[type='number']");
  let message = "میں درج ذیل سکنز آرڈر کرنا چاہتا ہوں:%0A";
  inputs.forEach(input => {
    const qty = parseInt(input.value);
    if (qty > 0) {
      const code = input.id.replace("qty-", "");
      message += `🟩 ${code} - ${qty} عدد%0A`;
    }
  });
  const phone = window.whatsappNumber;
  window.open(`https://wa.me/92${phone}?text=${message}`, "_blank");
}

fetchImages();
